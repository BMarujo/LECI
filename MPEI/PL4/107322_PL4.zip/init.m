function BF = init(n)
    BF = false(1,n);
end